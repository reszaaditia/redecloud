# Rede Cloud v16

Rede Cloud v16 adds a dedicated mobile Trash bottom navigation and full Trash selection workflow.

## Trash behavior
- Deleted files move to Trash with `trashed=true` and `deleted_at=NOW()`.
- Files remain restorable for 7 days.
- A background cleanup runs hourly and permanently removes expired Trash records and their physical files from `/data/uploads`.
- Trash supports long-press / click-and-hold selection.
- When Trash files are selected, the bottom selection toolbar provides **Batal**, **Pulihkan**, and **Hapus Permanen**.
- Permanent deletion removes both the PostgreSQL record and the physical stored file.

## Mobile navigation
Home · Recent · Sampah · Upload · Shared · Profil

## Update
Do not run `docker compose down -v`; keep existing database and upload volumes.


Rede Cloud v17 changes: Recent excludes trashed files; Trash bulk action is labeled 'Hapus' while performing permanent deletion; mobile bottom Upload is aligned with the other navigation icons without a circular background.
