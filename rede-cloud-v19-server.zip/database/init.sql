CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS users (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), name VARCHAR(120) NOT NULL, email VARCHAR(255) UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, role VARCHAR(20) NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
 storage_limit BIGINT NOT NULL DEFAULT 5368709120, suspended BOOLEAN NOT NULL DEFAULT FALSE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS folders (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,parent_id UUID REFERENCES folders(id) ON DELETE CASCADE,name VARCHAR(255) NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS files (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,folder_id UUID REFERENCES folders(id) ON DELETE SET NULL,original_name VARCHAR(500) NOT NULL,stored_name TEXT NOT NULL,mime_type VARCHAR(255),size BIGINT NOT NULL DEFAULT 0,favorite BOOLEAN NOT NULL DEFAULT FALSE,trashed BOOLEAN NOT NULL DEFAULT FALSE,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),deleted_at TIMESTAMPTZ);
CREATE TABLE IF NOT EXISTS shares (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),file_id UUID NOT NULL REFERENCES files(id) ON DELETE CASCADE,token VARCHAR(80) UNIQUE NOT NULL,expires_at TIMESTAMPTZ,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS app_settings(key VARCHAR(80) PRIMARY KEY,value TEXT NOT NULL);
INSERT INTO app_settings(key,value) VALUES('cloud_name','Rede Cloud') ON CONFLICT(key) DO NOTHING;
INSERT INTO app_settings(key,value) VALUES('cloud_icon','/assets/rede-cloud-logo.svg') ON CONFLICT(key) DO NOTHING;
CREATE INDEX IF NOT EXISTS idx_files_user_folder ON files(user_id,folder_id,trashed);
CREATE INDEX IF NOT EXISTS idx_files_deleted_at ON files(deleted_at) WHERE trashed=true;
CREATE INDEX IF NOT EXISTS idx_folders_user_parent ON folders(user_id,parent_id);
