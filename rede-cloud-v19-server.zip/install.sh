#!/bin/sh
set -eu
cd "$(dirname "$0")"
echo "Rede Cloud v5"
echo "1) docker compose up -d --build"
echo "2) open http://SERVER-IP:2027"
